package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;

import com.entity.Person;
import com.util.GetSqlSession;

@WebServlet("/insertPerson")
public class insertPerson extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public insertPerson() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		try {
			//分页技术
			List<Person> list=new ArrayList<Person>();
			SqlSession session = GetSqlSession.getSqlSession();
			list=session.selectList("selectAll",null,new RowBounds(2,4));
			for (Person person : list) {
				System.out.println(person);
			}
			//如果数据库的主键设置了自动增长，在generator中不需要identity配置
			Person person=new Person();
			person .setPersonid(11);
			person.setPersonname("zhou");
			session.update("updateById",person);
			session.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
