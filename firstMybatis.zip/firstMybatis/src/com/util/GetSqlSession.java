package com.util;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.naming.resources.Resource;

public class GetSqlSession {
	public static SqlSession getSqlSession() throws IOException {
		String resource = "mybatis-config.xml";
		InputStream input = Resources.getResourceAsStream(resource);
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(input);
		SqlSession sqlSession = factory.openSession();
		return sqlSession;

	}
}
